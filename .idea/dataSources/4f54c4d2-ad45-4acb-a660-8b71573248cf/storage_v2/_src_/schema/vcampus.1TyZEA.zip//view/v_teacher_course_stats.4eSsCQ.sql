create definer = root@localhost view v_teacher_course_stats as
select `u`.`user_id`          AS `user_id`,
       `u`.`real_name`        AS `real_name`,
       `u`.`department`       AS `department`,
       count(`c`.`course_id`) AS `total_courses`,
       sum(`c`.`enrolled`)    AS `total_students`
from (`vcampus`.`tbl_user` `u` left join `vcampus`.`tbl_course` `c` on ((`u`.`user_id` = `c`.`teacher_id`)))
where (`u`.`role` = 'TEACHER')
group by `u`.`user_id`, `u`.`real_name`, `u`.`department`;

-- comment on column v_teacher_course_stats.user_id not supported: 用户ID（学号/工号）

-- comment on column v_teacher_course_stats.real_name not supported: 真实姓名

-- comment on column v_teacher_course_stats.department not supported: 院系/部门

