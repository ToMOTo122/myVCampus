create definer = root@localhost view v_student_course_stats as
select `u`.`user_id`                                                               AS `user_id`,
       `u`.`real_name`                                                             AS `real_name`,
       `u`.`class_name`                                                            AS `class_name`,
       count(`cs`.`course_id`)                                                     AS `total_courses`,
       sum((case when (`cs`.`status` = 'COMPLETED') then `c`.`credit` else 0 end)) AS `completed_credits`,
       avg((case when (`cs`.`score` is not null) then `cs`.`score` else NULL end)) AS `avg_score`
from ((`vcampus`.`tbl_user` `u` left join `vcampus`.`tbl_course_selection` `cs`
       on ((`u`.`user_id` = `cs`.`student_id`))) left join `vcampus`.`tbl_course` `c`
      on ((`cs`.`course_id` = `c`.`course_id`)))
where (`u`.`role` = 'STUDENT')
group by `u`.`user_id`, `u`.`real_name`, `u`.`class_name`;

-- comment on column v_student_course_stats.user_id not supported: 用户ID（学号/工号）

-- comment on column v_student_course_stats.real_name not supported: 真实姓名

-- comment on column v_student_course_stats.class_name not supported: 班级（学生）

