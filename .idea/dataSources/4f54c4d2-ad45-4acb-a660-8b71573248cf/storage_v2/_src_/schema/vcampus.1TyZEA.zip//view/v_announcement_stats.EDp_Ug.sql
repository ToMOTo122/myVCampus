create definer = root@localhost view v_announcement_stats as
select `vcampus`.`tbl_announcement`.`category`          AS `category`,
       count(0)                                         AS `total_count`,
       sum(`vcampus`.`tbl_announcement`.`view_count`)   AS `total_views`,
       avg(`vcampus`.`tbl_announcement`.`view_count`)   AS `avg_views`,
       max(`vcampus`.`tbl_announcement`.`publish_date`) AS `latest_publish`
from `vcampus`.`tbl_announcement`
where (`vcampus`.`tbl_announcement`.`is_published` = true)
group by `vcampus`.`tbl_announcement`.`category`;

-- comment on column v_announcement_stats.category not supported: 公告分类

-- comment on column v_announcement_stats.latest_publish not supported: 发布时间

