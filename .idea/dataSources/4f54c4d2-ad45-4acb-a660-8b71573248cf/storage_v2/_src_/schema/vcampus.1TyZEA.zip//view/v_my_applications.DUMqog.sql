create definer = root@localhost view v_my_applications as
select `u`.`user_id`                                                AS `user_id`,
       `u`.`real_name`                                              AS `real_name`,
       count(`a`.`id`)                                              AS `total_applications`,
       sum((case when (`a`.`status` = '已完成') then 1 else 0 end)) AS `completed_applications`,
       sum((case when (`a`.`status` = '审核中') then 1 else 0 end)) AS `pending_applications`,
       sum((case when (`a`.`status` = '已拒绝') then 1 else 0 end)) AS `rejected_applications`
from (`vcampus`.`tbl_user` `u` left join `vcampus`.`tbl_application` `a` on ((`u`.`user_id` = `a`.`applicant_id`)))
group by `u`.`user_id`, `u`.`real_name`;

-- comment on column v_my_applications.user_id not supported: 用户ID（学号/工号）

-- comment on column v_my_applications.real_name not supported: 真实姓名

