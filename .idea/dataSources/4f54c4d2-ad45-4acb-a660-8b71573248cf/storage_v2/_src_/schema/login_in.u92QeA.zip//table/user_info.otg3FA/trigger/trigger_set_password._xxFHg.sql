create definer = root@localhost trigger trigger_set_password
    before insert
    on user_info
    for each row
begin
    if NEW.pwd is null then
        set NEW.pwd = concat(NEW.user_id,'123');
    end if;
end;

